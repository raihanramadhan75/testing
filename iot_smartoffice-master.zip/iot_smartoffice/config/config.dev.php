<?php
  $servername = "";
  $username = "";
  $password = "";
  $dbname = "";
  $data = "./logdata.txt";
?>
